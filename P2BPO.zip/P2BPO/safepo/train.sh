python train.py --algo p2bpo --env-id Safexp-CarButton1-v0 -c 4 --cost_limit 25 --seed 0
python train.py --algo p2bpo --env-id Safexp-PointButton1-v0 -c 4 --cost_limit 25 --seed 0
python train.py --algo p2bpo --env-id Ant-v3 -c 4 --cost_limit 25 --seed 0
python train.py --algo p2bpo --env-id Humanoid-v3 -c 4 --cost_limit 25 --seed 0
python train.py --algo p2bpo --env-id SafetyCarCircle-v0 -c 4 --cost_limit 25 --seed 0
python train.py --algo p2bpo --env-id SafetyBallCircle-v0 -c 4 --cost_limit 25 --seed 0
python train.py --algo p2bpo --env-id Safexp-PointGoal1-v0 -c 4 --cost_limit 25 --seed 0
python train.py --algo p2bpo --env-id Safexp-CarGoal1-v0 -c 4 --cost_limit 25 --seed 0

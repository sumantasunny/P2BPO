import abc
import torch
import torch.optim as optim

class PenaltyParam(abc.ABC):
    def __init__(self,
                 cost_limit: float,
                 penalty_param_init: float,
                 penalty_param_lr: float,
                 penalty_param_optimizer: str
                 ):
        self.cost_limit = cost_limit
        self.penalty_param_lr = penalty_param_lr

        init_value = max(penalty_param_init, 1e-5)
        self.penalty_param = torch.nn.Parameter(torch.as_tensor(init_value), requires_grad=True)
        # fetch optimizer from PyTorch optimizer package
        assert hasattr(optim, penalty_param_optimizer),  f'Optimizer={penalty_param_optimizer} not found in torch.'
        torch_opt = getattr(optim, penalty_param_optimizer)
        self.penalty_param_optimizer = torch_opt([self.penalty_param, ],
                                          lr=penalty_param_lr)

    def compute_penalty_param_loss(self, mean_ep_cost):
        return -self.penalty_param * (mean_ep_cost - self.cost_limit)

    def update_penalty_param(self, ep_costs):
        """ Update penalty_param
            Note: ep_costs obtained from: self.logger.get_stats('EpCosts')[0]
            are already averaged across MPI processes.
        """
        self.penalty_param_optimizer.zero_grad()
        penalty_param_loss = self.compute_penalty_param_loss(ep_costs)
        penalty_param_loss.backward()
        self.penalty_param_optimizer.step()
        self.penalty_param.data.clamp_(0)  # enforce: penalty_param in [0, inf]

import torch
from safepo.algos.policy_gradient import PG
from safepo.algos.penalty_param_base import PenaltyParam
import safepo.common.mpi_tools as mpi_tools
import numpy as np
import torch.nn.functional as F

class P2BPO(PG,PenaltyParam):
    '''
    
    '''
    def __init__(
            self,
            algo='p2bpo', 
            cost_limit=25., 
            clip=0.2, 
            penalty_param_init=0.001,
            penalty_param_lr=0.2, 
            penalty_param_optimizer='Adam', 
            use_standardized_reward=True, 
            use_standardized_cost=True,
            use_standardized_obs=False,
            use_reward_scaling=True,
            use_cost_value_function=True,
            use_kl_early_stopping=True,
            **kwargs
        ):
        PG.__init__(
            self, 
            algo=algo, 
            use_cost_value_function=use_cost_value_function,
            use_kl_early_stopping=use_kl_early_stopping, 
            use_standardized_reward=use_standardized_reward, 
            use_standardized_cost=use_standardized_cost, 
            use_standardized_obs=use_standardized_obs,
            use_reward_scaling=use_reward_scaling,
            **kwargs
        )

        PenaltyParam.__init__(
            self, 
            cost_limit=cost_limit,
            penalty_param_init=penalty_param_init, 
            penalty_param_lr=penalty_param_lr,
            penalty_param_optimizer=penalty_param_optimizer
        )

        self.clip = clip

    def algorithm_specific_logs(self):
        super().algorithm_specific_logs()
        self.logger.log_tabular('PenaltyParam', self.penalty_param.item())


    def compute_loss_pi(self, data: dict):
        # Policy loss
        dist, _log_p = self.ac.pi(data['obs'], data['act'])
        ratio = torch.exp(_log_p - data['log_p'])
        ratio_clip = torch.clamp(ratio, 1-self.clip, 1+self.clip)
        loss_pi = -(torch.min(ratio * data['adv'], ratio_clip * data['adv'])).mean()
        loss_pi -= self.entropy_coef * dist.entropy().mean()

        # # ensure that penalty_param is positive
        penalty_param = F.relu(self.penalty_param).item()
        cadv_ratio = (ratio * data['cost_adv']).mean()
        ep_costs = self.logger.get_stats('EpCosts')[0]
        cost_dev = ep_costs - self.cost_limit
        penalty = penalty_param * (cadv_ratio + (1-self.gamma)*cost_dev)
        sftplus_penalty = F.softplus(penalty, beta=10, threshold=0.8)
        loss_pi = loss_pi + sftplus_penalty
        if sftplus_penalty > 0:
            loss_pi /= (1. + penalty_param)

        # Useful extra info
        approx_kl = (0.5 * (dist.mean - data['act']) ** 2/ dist.stddev ** 2).mean().item()
        ent = dist.entropy().mean().item()
        pi_info = dict(kl=approx_kl, ent=ent, ratio=ratio_clip.mean().item())
        return loss_pi, pi_info

    def update(self):
        raw_data = self.buf.get()
        # pre-process data
        data = self.pre_process_data(raw_data)
        # Note that logger already uses MPI statistics across all processes..
        ep_costs = self.logger.get_stats('EpCosts')[0]
        self.update_penalty_param(ep_costs)
        self.update_policy_net(data=data)
        self.update_value_net(data=data)
        self.update_cost_net(data=data)
        self.update_running_statistics(raw_data)

conda env create -f environment.yml
echo "conda environment created"

conda install -c conda-forge libstdcxx-ng=12 -y
pip install -e .
echo "safepo installed"
cd safety-gym
pip install -e .
echo "safety-gym installed"
cd ../Bullet-Safety-Gym
pip install -e .
echo "bullete-safety-gym installed"
echo "Ready to go"